package com.example.iot;

public class HistoryTag {
		  private long id;
		  private long timestamp;
		  private int active;

		  public long getId() {
		    return id;
		  }

		  public void setId(long id) {
		    this.id = id;
		  }

		  public long getTimestamp() {
			return timestamp;
		  }

		  public void setTimestamp(long timestamp) {
			    this.timestamp = timestamp;
		  }
		  
		  public int getActive() {
				return active;
			  }

		  public void setActive(int active) {
			    this.active = active;
		  }
		  // Will be used by the ArrayAdapter in the ListView
		  @Override
		  public String toString() { 
		    return String.valueOf(id);
		  }
		} 