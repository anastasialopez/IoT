package com.example.iot;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import android.os.Bundle;
import android.app.Activity;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class DisplayActiveTags extends Activity {
	private TagsDataSource datasourceT;
	private HistoryTagsDataSource datasourceH;
	static final String URL = "https://dl.dropboxusercontent.com/u/21231089/inventoryOn.xml";
	//static final String URL = "https://dl.dropboxusercontent.com/u/19591347/inventoryOn.xml";
	static final String KEY_ITEM = "item";
	static final String KEY_ID = "epc";
	static final String KEY_TS = "ts";
	static Document doc;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_display_active_tags);

		ListView list = (ListView) findViewById(R.id.list_ac);
		list.setSelector(android.R.color.transparent);

		// Show the Up button in the action bar.
		//setupActionBar();+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		XMLParser parser = new XMLParser();
		String xml = parser.getXmlFromUrl(URL); // getting XML
		doc = parser.getDomElement(xml); // getting DOM element
		Tag oldTag = new Tag();

		datasourceT = new TagsDataSource(this);
		datasourceT.open();
		datasourceH = new HistoryTagsDataSource(this);
		datasourceH.open();

		// Tags from the last time that it was checked the inventary
		List<Tag> oldValues = datasourceT.getAllActiveTags();
		// Store all tags that have been read from XML
		ArrayList<String> tagsXML = new ArrayList<String>();

		NodeList nl = doc.getElementsByTagName(KEY_ITEM);
		// looping through all item nodes <item>
		for (int i = 0; i < nl.getLength(); i++) {
			Element e = (Element) nl.item(i);
			if (datasourceT.existsTag(Long.parseLong(parser.getValue(e, KEY_ID))) == 0) {
			// if the tag is new, it is inserted on both tables (tag and historyTags) with the state IN.
					datasourceT.createTag(Long.parseLong(parser.getValue(e, KEY_ID)), 1, 0, " ");
					/*datasourceH.createHistoryTag(
						Long.parseLong(parser.getValue(e, KEY_ID)),
						Long.parseLong(parser.getValue(e, KEY_TS)), 1);*/
					java.util.Date date = new java.util.Date();
					long tsTime = new Timestamp(date.getTime()).getTime();
					datasourceH.createHistoryTag(Long.parseLong(parser.getValue(e, KEY_ID)), tsTime, 1);
			} else {
				// if exists, check if the tag is active or no
				oldTag = datasourceT.getTag(Long.parseLong(parser.getValue(e,KEY_ID)));

				if (oldTag.getActive() == 0){ // if it is not active (OUT), update to IN.
					datasourceT.updateTag(oldTag, 1);
					// insert a record in the HistoryTags Table with the state IN.
					java.util.Date date = new java.util.Date();
					long tsTime = new Timestamp(date.getTime()).getTime();
					datasourceH.createHistoryTag(oldTag.getId(), tsTime, 1);
				}
			}
			tagsXML.add(parser.getValue(e, KEY_ID));
		}

		for (int i = 0; i < oldValues.size(); ++i) {
			// if the tag was IN before but now is OUT, update the Tag Table and insert in HistoryTable
			if (!tagsXML.contains(oldValues.get(i).toString())) {
				java.util.Date date = new java.util.Date();
				long tsTime = new Timestamp(date.getTime()).getTime();
				datasourceH.createHistoryTag(oldValues.get(i).getId(), tsTime, 0);
				datasourceT.updateTag(oldValues.get(i), 0);

				// show a message to inform to the user that the tag is gone.
				CharSequence text = "The tag with ID:" + oldValues.get(i).toString() + " is gone.";
				int duration = Toast.LENGTH_SHORT;

				Toast toast = Toast.makeText(getApplicationContext(), text, duration);
				toast.show();
			}
		}

		List<Tag> values = datasourceT.getAllActiveTags();

		// Use the SimpleCursorAdapter to show the elements in the ListView
		ArrayAdapter<Tag> adapter = new ArrayAdapter<Tag>(this,
				android.R.layout.simple_list_item_1, values);
		list.setAdapter(adapter);
	}

	@Override
	protected void onResume() {
		datasourceH.open();
		super.onResume();
	}

	@Override
	protected void onPause() {
		datasourceT.close();
		datasourceH.close();
		super.onPause();
	}

}
