package com.example.iot;

import java.util.List;

import android.os.Bundle;
import android.app.ListActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.content.Intent;

public class DisplayHistoryTags extends ListActivity {
	private HistoryTagsDataSource datasourceH;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_display_history_active_tags);
		// Show the Up button in the action bar.
		//setupActionBar(); +++++++++++++++++++limpieza++++++++++++++++++++++++++++++++++++++++++++++++++++++
		
        datasourceH = new HistoryTagsDataSource(this);
	    datasourceH.open();
	    
	    List<HistoryTag> values = datasourceH.getAllTagsOrdered();
	    
	    // Use the SimpleCursorAdapter to show the elements in the ListView
	    ArrayAdapter<HistoryTag> adapter = new ArrayAdapter<HistoryTag>(this,
	        android.R.layout.simple_list_item_1, values);
	    setListAdapter(adapter);
	}
	
	@Override 
    public void onListItemClick(ListView currentTag, View v, int position, long id) {
        // When a list item is clicked start another activity and send the id to the new one.
		String ide = ((TextView) v).getText().toString();
		Intent intent = new Intent(this, DetailHistoryTag.class);
		intent.putExtra("id",ide);
		startActivity(intent);
		
    }
}
