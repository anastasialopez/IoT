package com.example.iot;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;

public class MainActivity extends Activity {
	
	  @TargetApi(Build.VERSION_CODES.GINGERBREAD) @Override
	  public void onCreate(Bundle savedInstanceState) {
	    	    
	    StrictMode.ThreadPolicy policy = new StrictMode.
	    ThreadPolicy.Builder().permitAll().build();
	    StrictMode.setThreadPolicy(policy);
	    super.onCreate(savedInstanceState);
	    
	    setContentView(R.layout.activity_main);  
    }

	  public void checkActiveTags(View view) {
		  Intent intent = new Intent(this, DisplayActiveTags.class);
		  startActivity(intent);
	  }
	  
	  public void showKnownDevices(View view) {
		  Intent intent = new Intent(this, Shelf_Activity.class);
		  startActivity(intent);
	  }
	 
	  @Override
	  protected void onResume() {
		    super.onResume();
	  }

	  @Override
	  protected void onPause() {
	    super.onPause();
	  }
} 

