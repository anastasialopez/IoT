package com.example.iot;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;

public class Shelf_Activity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.shelf);
		
		final ImageButton shelf1 = (ImageButton)findViewById(R.id.image1);
		final ImageButton shelf2 = (ImageButton)findViewById(R.id.image2);
		final ImageButton shelf3 = (ImageButton)findViewById(R.id.image3);
		final ImageButton shelf4 = (ImageButton)findViewById(R.id.image4);
		
		shelf1.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if(shelf1.getContentDescription().toString().contains("enable")){
					shelf1.setBackgroundColor(getResources().getColor(R.color.red));
					String disabled = "disable";
					shelf1.setContentDescription(disabled);
				}
				else{
					shelf1.setBackgroundColor(getResources().getColor(R.color.green));
					String enable = "enable";
					shelf1.setContentDescription(enable);
				}
			}
			
		});
		
		shelf1.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if(shelf1.getContentDescription().toString().contains("enable")){
					shelf1.setBackgroundColor(getResources().getColor(R.color.red));
					String disabled = "disable";
					shelf1.setContentDescription(disabled);
				}
				else{
					shelf1.setBackgroundColor(getResources().getColor(R.color.green));
					String enable = "enable";
					shelf1.setContentDescription(enable);
				}
			}
			
		});
		
		shelf2.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if(shelf2.getContentDescription().toString().contains("enable")){
					shelf2.setBackgroundColor(getResources().getColor(R.color.red));
					String disabled = "disable";
					shelf2.setContentDescription(disabled);
				}
				else{
					shelf2.setBackgroundColor(getResources().getColor(R.color.green));
					String enable = "enable";
					shelf2.setContentDescription(enable);
				}
			}
			
		});
		
		shelf3.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if(shelf3.getContentDescription().toString().contains("enable")){
					shelf3.setBackgroundColor(getResources().getColor(R.color.red));
					String disabled = "disable";
					shelf3.setContentDescription(disabled);
				}
				else{
					shelf3.setBackgroundColor(getResources().getColor(R.color.green));
					String enable = "enable";
					shelf3.setContentDescription(enable);
				}
			}
			
		});
		
		shelf4.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				if(shelf4.getContentDescription().toString().contains("enable")){
					shelf4.setBackgroundColor(getResources().getColor(R.color.red));
					String disabled = "disable";
					shelf4.setContentDescription(disabled);
				}
				else{
					shelf4.setBackgroundColor(getResources().getColor(R.color.green));
					String enable = "enable";
					shelf4.setContentDescription(enable);
				}
			}
			
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.shelf_, menu);
		return true;
	}

}
