package com.example.iot;

//import java.sql.Date;
//import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;


public class DetailHistoryTag extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_detail_history_tag);
		
		Intent intent = getIntent();
	    String id = intent.getStringExtra("id");
		
		HistoryTagsDataSource datasourceH = new HistoryTagsDataSource(this);
	    datasourceH.open();
	    List<HistoryTag> tags = datasourceH.getRecordTag(id);
	    ArrayList <String> ts = new ArrayList <String>();
	   // ArrayList <String> active = new ArrayList <String>();+++++++++++++++++++++++
	  //  for(int i = 0; i < tags.size(); i++){
	    for(int i = tags.size()-1; i >= 0; i--){
	    //	ts.add(Long.toString(tags.get(i).getTimestamp()));+++++++++++++++++++++++++++++
	    	
	    	if(tags.get(i).getActive() == 1){
	    		//active.add("IN");
	    		ts.add(Long.toString(tags.get(i).getTimestamp()) + "                        IN");
	    	}else{
	    		//active.add("OUT");
	    		ts.add(Long.toString(tags.get(i).getTimestamp()) + "                        OUT");
	    	}
	    }
	    
	    ListView tsListView = (ListView) findViewById(R.id.ts_list);
	    tsListView.setSelector(android.R.color.transparent);
	    
	    ArrayAdapter<String> adapterTS = new ArrayAdapter<String>(this,
	    		android.R.layout.simple_list_item_1, ts);
	    
	    tsListView.setAdapter(adapterTS);
	    
	 /*   ListView activeListView = (ListView) findViewById(R.id.active_list);++++++++++++++++++++++
	    activeListView.setSelector(android.R.color.transparent);
	    
	    ArrayAdapter<String> adapterActive = new ArrayAdapter<String>(this,
	    		android.R.layout.simple_list_item_1, active);
	    
	    activeListView.setAdapter(adapterActive);*/
	}

}
