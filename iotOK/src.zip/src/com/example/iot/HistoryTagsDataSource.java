package com.example.iot;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class HistoryTagsDataSource {

	private SQLiteDatabase database;
	private MySQLiteHelper dbHelper;
	// Database fields
	private String[] allColumns = { MySQLiteHelper.COLUMN_ID,
			MySQLiteHelper.COLUMN_TS, MySQLiteHelper.COLUMN_ACTIVE };

	public HistoryTagsDataSource(Context context) {
		dbHelper = new MySQLiteHelper(context);
	}

	public void open() throws SQLException {
		database = dbHelper.getWritableDatabase();
	}

	public void close() {
		dbHelper.close();
	}

	public HistoryTag createHistoryTag(long id, long ts, int active) {
		ContentValues values = new ContentValues();
		values.put(MySQLiteHelper.COLUMN_ID, id);
		values.put(MySQLiteHelper.COLUMN_TS, ts);
		values.put(MySQLiteHelper.COLUMN_ACTIVE, active);
		database.insert(MySQLiteHelper.TABLE_HISTORYTAGS, null, values);
		Cursor cursor = database.query(MySQLiteHelper.TABLE_HISTORYTAGS,
				allColumns, MySQLiteHelper.COLUMN_ID + " = " + id + " AND "
				+ MySQLiteHelper.COLUMN_TS + " = " + ts, null, null, null, null);
		System.out.println("Tag with id: " + id + " has been inserted in HistoryTags");
		cursor.moveToFirst();
		HistoryTag newHistoryTag = cursorToHistoryTag(cursor);
		cursor.close();
		return newHistoryTag;
	}

	public void deleteHistoryTag(HistoryTag tag) {
		long id = tag.getId();
		long ts = tag.getTimestamp();
		database.delete(MySQLiteHelper.TABLE_HISTORYTAGS,
				MySQLiteHelper.COLUMN_ID + " = " + id + " AND "
				+ MySQLiteHelper.COLUMN_TS + " = " + ts, null);
		System.out.println("HistoryTag deleted with id: " + id + " and timestamp: " + ts);
	}

	public List<HistoryTag> getAllTags() {
		List<HistoryTag> tags = new ArrayList<HistoryTag>();

		Cursor cursor = database.query(MySQLiteHelper.TABLE_HISTORYTAGS,
				allColumns, null, null, null, null, null);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			HistoryTag tag = cursorToHistoryTag(cursor);
			tags.add(tag);
			cursor.moveToNext();
		}
		// close the cursor
		cursor.close();
		return tags;
	}
	
	public List<HistoryTag> getAllTagsOrdered() {
		List<HistoryTag> tags = new ArrayList<HistoryTag>();

		Cursor cursor = database.query(MySQLiteHelper.TABLE_HISTORYTAGS,
				allColumns, null, null, MySQLiteHelper.COLUMN_ID, null, null);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			HistoryTag tag = cursorToHistoryTag(cursor);
			tags.add(tag);
			cursor.moveToNext();
		}
		// Close the cursor
		cursor.close();
		return tags;
	}

	public List<HistoryTag> getRecordTag(String id) {
		String[] columns = { MySQLiteHelper.COLUMN_TS, MySQLiteHelper.COLUMN_ACTIVE };
		List<HistoryTag> tags = new ArrayList<HistoryTag>();
		Cursor cursor = database.query(MySQLiteHelper.TABLE_HISTORYTAGS,
				columns, MySQLiteHelper.COLUMN_ID + " = " + id, null, null,
				null, null);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			HistoryTag tag = cursorToHistoryTag2(cursor);
			tags.add(tag);
			cursor.moveToNext();
		}
		// Close the cursor
		cursor.close();
		return tags;
	}

	private HistoryTag cursorToHistoryTag(Cursor cursor) {
		HistoryTag tag = new HistoryTag();
		tag.setId(cursor.getLong(0));
		tag.setTimestamp(cursor.getLong(1));
		tag.setActive(cursor.getInt(2));
		return tag;
	}

	private HistoryTag cursorToHistoryTag2(Cursor cursor) {
		HistoryTag tag = new HistoryTag();
		tag.setTimestamp(cursor.getLong(0));
		tag.setActive(cursor.getInt(1));
		return tag;
	}
}
